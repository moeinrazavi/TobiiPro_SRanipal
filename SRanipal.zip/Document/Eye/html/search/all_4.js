var searchData=
[
  ['gaze_5forigin_5fmm',['gaze_origin_mm',['../struct_vive_s_r_1_1anipal_1_1_eye_1_1_single_eye_data.html#aede341609f0341564a6b329da51c4170',1,'ViveSR::anipal::Eye::SingleEyeData']]],
  ['gazerayparameter',['GazeRayParameter',['../struct_vive_s_r_1_1anipal_1_1_eye_1_1_gaze_ray_parameter.html',1,'ViveSR::anipal::Eye']]],
  ['getstatus',['GetStatus',['../namespace_vive_s_r_1_1anipal.html#a0b5cf88515072242a93ec853327955e3',1,'ViveSR::anipal']]],
  ['getting_20started_20with_20sranipal_20c_20sdk',['Getting Started with SRanipal C SDK',['../index.html',1,'']]]
];
