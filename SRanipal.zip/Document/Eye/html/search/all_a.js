var searchData=
[
  ['sensitive_5ffactor',['sensitive_factor',['../struct_vive_s_r_1_1anipal_1_1_eye_1_1_gaze_ray_parameter.html#a962a7531779c27b0f9145401ce885f24',1,'ViveSR::anipal::Eye::GazeRayParameter']]],
  ['singleeyedata',['SingleEyeData',['../struct_vive_s_r_1_1anipal_1_1_eye_1_1_single_eye_data.html',1,'ViveSR::anipal::Eye']]],
  ['sranipal_5fgetversion',['SRanipal_GetVersion',['../namespace_vive_s_r_1_1anipal.html#a4c2ff1f15228f29412d3c6e0e1186e89',1,'ViveSR::anipal']]]
];
