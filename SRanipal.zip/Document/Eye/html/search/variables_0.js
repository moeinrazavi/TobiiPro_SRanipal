var searchData=
[
  ['combined',['combined',['../struct_vive_s_r_1_1anipal_1_1_eye_1_1_verbose_data.html#ab4371061dc6ba9bd6b8bba63f1357ee3',1,'ViveSR::anipal::Eye::VerboseData']]]
];
