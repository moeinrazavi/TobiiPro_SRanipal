var searchData=
[
  ['gaze_5forigin_5fmm',['gaze_origin_mm',['../struct_vive_s_r_1_1anipal_1_1_eye_1_1_single_eye_data.html#aede341609f0341564a6b329da51c4170',1,'ViveSR::anipal::Eye::SingleEyeData']]]
];
