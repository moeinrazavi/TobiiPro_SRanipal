var indexSectionsWithContent =
{
  0: "afgirsv",
  1: "v",
  2: "girs",
  3: "a",
  4: "fg"
};

var indexSectionNames =
{
  0: "all",
  1: "namespaces",
  2: "functions",
  3: "enums",
  4: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Namespaces",
  2: "Functions",
  3: "Enumerations",
  4: "Pages"
};

