var searchData=
[
  ['getstatus',['GetStatus',['../namespace_vive_s_r_1_1anipal.html#a0b5cf88515072242a93ec853327955e3',1,'ViveSR::anipal']]],
  ['getting_20started_20with_20sranipal_20c_20sdk',['Getting Started with SRanipal C SDK',['../index.html',1,'']]]
];
